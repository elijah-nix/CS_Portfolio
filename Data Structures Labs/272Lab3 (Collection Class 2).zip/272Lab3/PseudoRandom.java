
public class PseudoRandom {
	//instance variables
	//(multiplier * seed + increment) % modulus
	//(mult * seed + incr) % mod
	
	private int seed;
	private int mult;
	private int incr;
	private int mod;
	
	//Constructor with 4 integer parameters: seed, mult, incr, mod
	//If the Constructor's mod value is 0 or 1, the program will warn the user.
	public PseudoRandom (int _seed, int _mult, int _incr, int _mod) {
		seed = _seed;
		mult = _mult;
		incr = _incr;
		mod = _mod;
		if(mod == 1 || mod == 0 || mod == -1) {
			System.out.println("WARNING! Setting modulus to -1, 0, or 1 leads to errors.");
		}
	}
	
	//The "nextRand" method carries out our pseudorandom equation that calculates the new seed, assigns the new seed to the object in the parameter, and prints the calculation
	//Parameter: Object of type PseudoRandom
	//Returns the new seed value
	//Preconditions: Object must be of type PseudoRandom. Modulus must not be zero.
	public static int nextRand(PseudoRandom obj) {
		int newSeed = 0;
		try{
			if(obj.getMod() == 1 || obj.getMod() == -1) {
				System.out.println("Mod of -1 or 1 gives 0 every time.");
				return newSeed;
			}
			newSeed = (obj.getMult() * obj.getSeed() + obj.getIncr()) % obj.getMod();
			//System.out.print("(" + obj.getMult() + " * " + obj.getSeed() + " + " + obj.getIncr() + ") % " + obj.getMod() + " = " + newSeed + "\n");
			obj.setSeed(newSeed);
			//System.out.println("The new seed is " + newSeed);
		} catch (ArithmeticException e){ 
			System.out.println(e.getMessage() + ". Cannot compute new seed.");
		}
		return newSeed; 
	}
	
	//The "nextRandDouble" method uses the "nextRand" method to output the new seed divided by the modulus
	//Parameter: Object of type PseudoRandom
	//Returns a double value between 0 and 1
	//Preconditions: Object must be of type PseudoRandom. Modulus must not be zero.
	public static double nextRandDouble(PseudoRandom obj) {
		double seed = nextRand(obj);
		if(obj.getMod() == 0) {
			throw new ArithmeticException("/ by zero");
		}
		double percent = seed / obj.getMod();
		return percent;
	}
	
	//The following 8 methods are getters and setters
	
	public int getSeed() {
		return seed;
	}

	public void setSeed(int seed) {
		this.seed = seed;
	}

	public int getMult() {
		return mult;
	}

	public void setMult(int mult) {
		this.mult = mult;
	}

	public int getIncr() {
		return incr;
	}

	public void setIncr(int incr) {
		this.incr = incr;
	}

	public int getMod() {
		return mod;
	}

	public void setMod(int mod) {
		this.mod = mod;
	}

	public static void main (String args[]) {
		
		//The following are test cases. See console
		//Using non-zero values
		PseudoRandom rand1 = new PseudoRandom(2, 3, 4, 5);		
		System.out.println(nextRand(rand1));
		System.out.println(nextRand(rand1));
		System.out.println(nextRand(rand1));
		
		//Using a zero value in the modulus
		//Results in an error message
		PseudoRandom rand2 = new PseudoRandom(2, 3, 4, 0);
		System.out.println(nextRand(rand2));
		
		//After the error, the code continues
		//Code still computes even with larger integers
		PseudoRandom rand3 = new PseudoRandom(9999999, 9999999, 56, 78);
		System.out.println(nextRand(rand3));
		System.out.println(nextRand(rand3));
		System.out.println(nextRand(rand3));
		
		//Mod = 1 gives 0 every time. The method tells the user.
		PseudoRandom rand4 = new PseudoRandom(123,234,345,1);
		System.out.println(nextRand(rand4));
		System.out.println(nextRand(rand4));
		System.out.println(nextRand(rand4));
		
		//Note: If mult or mod is the only negative value, every new seed will alternate between positive and negative
		//Note: Is seed is the only negative value, every new seed will be negative
	
		//The following code are tests for Lab 3.
		//The fourth test shows that dividing by 0 throws an ArithmeticException when attempting to divide by zero
		
		System.out.println("Data from Lab 3:");
		System.out.println(nextRandDouble(rand3));
		System.out.println(nextRandDouble(rand4));
		System.out.println(nextRandDouble(rand1));
		System.out.print(nextRandDouble(rand2));
	}
	
}
