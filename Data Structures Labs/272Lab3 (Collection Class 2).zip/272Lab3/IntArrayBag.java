
public class IntArrayBag {
	
	private int[] data;
	private int manyItems;
	
	/** @precondition
	*   initialCapacity is non-negative.
	* @postcondition
	*   This bag is empty and has the given initial capacity.
	* @exception IllegalArgumentException
	*   Indicates that initialCapacity is negative.
	* @exception OutOfMemoryError
	*/
	public IntArrayBag(int initialCapacity){
		if (initialCapacity < 0) {
			throw new IllegalArgumentException
			("The initialCapacity is negative: " + initialCapacity);
		}
		data = new int[initialCapacity];
		manyItems = 0;
	}
	
	
	/** @postcondition
	 *   The return value is the number of copies of target in the Bag.
	 *   */
	public int countOccurrences(int target){
		int answer = 0;
		int index;
		for (index = 0; index < manyItems; index++){
			if (target == data[index])
				answer++;
			}
		return answer;
	}
	
	/** @precondition Parameter object must be of type IntArrayBag
	 * @param object of type IntArrayBag
	 * @return true if the two bags include the same amount of each data point.
	 */
	public boolean equals(IntArrayBag b) {	
		if(b.getManyItems() != this.getManyItems()) {
			return false;
		}

		for(int i = 0; i < b.getManyItems(); i++) {
			for(int j = 0; j < b.getManyItems(); j++) {
				if(this.data[i] == b.data[j]) {
					if(this.countOccurrences(this.data[i]) != b.countOccurrences(b.data[j])) {
						return false;
					}
				}
			}
		}
		return true;
	}

	//The following 4 methods are getters and setters
	public int[] getData() {
		return data;
	}

	public void setData(int[] data) {
		this.data = data;
		manyItems = data.length;
	}

	public int getManyItems() {
		return manyItems;
	}

	public void setManyItems(int manyItems) {
		this.manyItems = manyItems;
	}
	
	public static void main(String args[]) {
		//This first test compares two IntArrayBag objects with the same amount of each number in different orders
		int[] data1 = {2,0,1,2,3,3,3,4,4,4};
		int[] data2 = {3,3,3,4,4,4,0,1,2,2};
		IntArrayBag bag1 = new IntArrayBag(15);
		IntArrayBag bag2 = new IntArrayBag(15);
		bag1.setData(data1);
		bag2.setData(data2);
		System.out.println(bag1.equals(bag2));
		
		//Second test compares two IntArrayBag objects with different amounts of each number
		data1[0] = 0;
		bag1.setData(data1);
		System.out.println(bag1.equals(bag2));
		
		//Third test compares two IntArrayBag objects with different array lengths
		int[] data3 = {0,0,0};
		IntArrayBag bag3 = new IntArrayBag(15);
		bag3.setData(data3);
		System.out.println(bag1.equals(bag3));
		
		
	}
}
