import java.io.FileWriter;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class EmployeeSet extends Employee{
	int capacity;
	int numEmp;
	Employee[] empSet;
	
	public EmployeeSet() {
		empSet = new Employee[10];
		numEmp = 0;
		capacity = 10;
	}
	
	public int size() {
		return numEmp;
	}
	
	
	//
	public void add(Employee a) {
		int id = a.getId();
		if ((a != null) && (a instanceof Employee) && (this.contains(id) == false)){
			if (numEmp == empSet.length){
				capacity = (numEmp + 1)*2;
				ensureCapacity((numEmp + 1)*2);
				//System.out.println("test");
			}
			this.empSet[numEmp] = a;
			numEmp++;
			System.out.println(numEmp);
			//System.out.println("YAY");
		} else {
			//System.out.println("OOPS");
		}
	}

	public boolean remove(int eID) {
		for(int i = 0; i < numEmp; i++) {
			if(this.empSet[i].getId() == eID) {
				numEmp -= 1;
				empSet[i] = empSet[numEmp];
				empSet[numEmp] = null;
				return true;
			}
		}
		return false;
	}
	
	public void ensureCapacity(int minimumCapacity) {
		Employee[] biggerArray;
		if (empSet.length < minimumCapacity){
			biggerArray = new Employee[minimumCapacity];
			System.arraycopy(empSet, 0, biggerArray, 0, numEmp);
			empSet = biggerArray;
			System.out.print(getCapacity());
		}
	}
	
	public boolean contains(int eID) {
		for(int i = 0; i < numEmp; i++) {
			if(this.empSet[i].getId() == eID) {
				return true;
			}
		}
		return false;
	}
	
	public void toFile(String fileName) throws IOException {
		if(this instanceof EmployeeSet) {
			FileWriter output = new FileWriter(fileName);
			output.write("Employee Name, Employee Number, State, Zip, Age, Manager Name");
			output.write(System.lineSeparator());
			for(int i = 0; i < this.numEmp; i++) {
				output.write(empSet[i].toString(empSet[i]));
				output.write(System.lineSeparator());
				//System.out.println("Success");
			}
			output.close();
		}
		
	}
	
	//The following functions are getters and setters. Some getters are removed to avoid redundancy
	public int getCapacity() {
		return capacity;
	}

	public void setCapacity(int capacity) {
		this.capacity = capacity;
	}

	public void setNumEmp(int numEmp) {
		this.numEmp = numEmp;
	}

	public Employee[] getEmpSet() {
		return empSet;
	}

	public void setEmpSet(Employee[] empSet) {
		this.empSet = empSet;
	}
	
	public static void main(String args[]) throws IOException{
			EmployeeSet set = new EmployeeSet();
			BufferedReader inputStream = new BufferedReader(new FileReader("core_dataset.csv"));
			inputStream.readLine();
			for(int i = 0; i < 301; i++) {
				String[] employeeData = inputStream.readLine().split(",");
				Employee a = new Employee();
				a.setName(employeeData[1].replaceAll("[^a-zA-Z0-9_-]", "") + " " + employeeData[0].replaceAll("[^a-zA-Z0-9_-]", ""));
				a.setId(Integer.parseInt(employeeData[2]));
				a.setState(employeeData[3]);
				a.setZipCode(Integer.parseInt(employeeData[4]));
				a.setAge(Integer.parseInt(employeeData[5]));
				a.setAdvisor(employeeData[6]);
				set.add(a);
				//System.out.print(a.toString(a));
				//System.out.println("Done");
				//System.out.println(set.getCapacity());
			}
			inputStream.close();
			
			//Should be true
			System.out.println(set.contains(1402065303));
			
			//Practice test employee is Lynn Daneault
			Employee test = new Employee(set.empSet[287]);
			test.toString(test);
			System.out.print(test.toString(test));
			
			set.add(test);
			
			//Daneault Lynn is deleted and Alex Sweetwater should be number 290. Total should be 301 after this
			set.remove(1402065303);
			
			//Once Lynn is removed, this should return false
			System.out.println(set.contains(1402065303));
			
			//Now, Lynn is added to the set again
			set.add(test);
			
			//data sent to test file INCLUDED IN LAB 3 ZIP
			set.toFile("empTest.csv");
			System.out.println(set.getCapacity());
			
	}
	
}
