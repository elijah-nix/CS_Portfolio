import java.io.IOException;

public class Employee implements Cloneable {

	
	//instance variables.
	private String name;
	private int id;
	private int age;
	private String state;
	private int zipCode;
	private String advisor;

	//Employee constructor with no parameters.
	public Employee(){
		name = null;
		id = 0;
		age = 0;
		state = null;
		zipCode = 0;
		advisor = null;
	}
	
	//Constructor with object parameter
	//This constructor creates a new Employee object by copying the values of another Employee object
	//Preconditions: object must not be null and must be an object of the "Employee" class
	public Employee(Object obj){
		if ((obj != null) && (obj instanceof Employee )) {
			Employee emp = (Employee) obj;
			this.name = new String(emp.name);
			this.id = emp.id;
			this.age = emp.age;
			this.state = new String(emp.state);
			this.zipCode = emp.zipCode;
			this.advisor = new String(emp.advisor);
		}
	}
	
	//The "equals" method checks if two Employee objects share the same ID
	//Method with object parameter
	//If both objects share the same ID, the method returns a boolean value of "true"
	//If both objects don't share the same ID, the method returns a boolean value of "false"
	//Preconditions: object must not be null and must be an instance of the Employee class
	public boolean equals(Object obj) {
		if ((obj != null) && (obj instanceof Employee )) {
			if(((Employee) obj).getId() == id) {
				return true;
			}
		}
		return false;
		
	}
	
	//The "clone" method makes an exact copy of an existing object of type Employee to a different reference
	//Method with no parameter
	//Returns an Employee object
	//Preconditions: Class must implement Cloneable
	public Employee clone() {
		Employee answer;            
		try {         
			answer = (Employee) super.clone( );        
			answer.name = new String(name);         
			answer.id = id;
			answer.age = age;
			answer.state = new String(state);
			answer.zipCode = zipCode;
			answer.advisor = new String(advisor);
		}      
		catch (CloneNotSupportedException e){ 
			System.out.println(e.getMessage());    
			throw new RuntimeException ("This class does not implement Cloneable.");      
		}          
		return answer;   
	}
	
	//The "toString" method returns the contents of the object in order by instance variable
	//Method with Employee object parameter
	//Returns a String that lists the instance variables' contents
	//Preconditions: parameter must be an object of type Employee
	public String toString(Employee obj) {
		return obj.getName() + "," + obj.getId() + "," + 
		obj.getState() + "," + obj.getZipCode() + "," + obj.getAge() + 
		"," + obj.getAdvisor();
	}
	
	//The following 12 methods are getters and setters
	
	public String getName() {
		return name;
		}

	public void setName(String name) {
		this.name = name;
		}



	public int getId() {
		return id;
		}



	public void setId(int id) {
		this.id = id;
		}



	public int getAge() {
		return age;
		}



	public void setAge(int age) {
		this.age = age;
		}


	public String getState() {
		return state;
		}



	public void setState(String state) {
		this.state = state;
		}


	public int getZipCode() {
		return zipCode;
		}



	public void setZipCode(int zipCode) {
		this.zipCode = zipCode;
		}



	public String getAdvisor() {
		return advisor;
		}



	public void setAdvisor(String advisor) {
		this.advisor = advisor;
		}
	
	public static void main(String args[]) throws IOException{
		
		//The following prints elaborate test cases
		
		System.out.print("NOTE: object 1 refers to the test1 object. Object 2 to test2 and so on.\n\n");
		
		System.out.print("Creating test object 1 and setting instance variables.\n\n");
		
		Employee test1 = new Employee();
		test1.setAdvisor("Terry");
		test1.setAge(40);
		test1.setId(1234567890);
		test1.setName("Crews");
		test1.setState("NM");
		test1.setZipCode(88001);
		
		System.out.print("Testing the toString method:\n\n");
		
		System.out.print(test1.toString(test1) + "\n");
		
		System.out.print("Testing the clone method by cloning object 1\n\n");
		Employee test2 = test1.clone();
		
		System.out.print("The following printed reference variables for object 1 and object 2 should be different:\n\n");
		
		System.out.print(test1 +"\n" + test2 + "\n\n");
		
		System.out.print("Printing the cloned objcet--object 2--using the toString method. The output should be identical to object 1.\n\n");
		
		System.out.print(test2.toString(test2) + "\n\n");
		
		System.out.print("Since object 1 and object 2 have identical IDs, the self-defined equals method should print \"true\" after comparing the two\n\n");
		
		System.out.print(test1.equals(test2) + "\n\n");
		
		test2.setId(123);
		
		System.out.print("After setting the ID of object 2 to \"123\", here are the new variables printed with the toString method.\n\n");
		
		System.out.print(test2.toString(test2) + "\n");
		
		System.out.print("Since the IDs between object 1 and object 2 are different, the equals method should print \"false\".\n\n");
		
		System.out.print(test1.equals(test2) + "\n\n");
		
		System.out.print("Using the constructor with an object parameter, we should get a new object--object 3--with the same values as object 1.\n\nObject 3 printed using the toString method:\n\n");
		
		Employee test3 = new Employee(test1);
		
		System.out.print(test3.toString(test3) + "\n");
		
		System.out.print("Using the constructor with no  parameter, we should get a new object--object 4-- with \"null\" or \"0\" for each instance variable.\n\n");
		
		Employee test4 = new Employee();
		
		System.out.print(test4.toString(test4));
		}
}