package intNodePackage;

public class IntNodeTest {
	public static void main(String args[]) {
		System.out.println("Testing constructors");
		IntNode nodeA = new IntNode();
		nodeA.setData(100);
		System.out.println(nodeA.toString());
		
		nodeA = new IntNode(55, nodeA);
		System.out.println(nodeA.toString());
		
		nodeA = new IntNode(3, nodeA);
		System.out.println(nodeA.toString());
		
		nodeA = new IntNode(8000, nodeA);
		System.out.println(nodeA.toString());
		
		System.out.println("Testing the addNode function");
		nodeA.addNodeAfterThis(9);
		System.out.println(nodeA.toString());
		
		nodeA.addNodeAfterThis(9);
		System.out.println(nodeA.toString());
		
		nodeA.addNodeAfterThis(9);
		System.out.println(nodeA.toString());
		
		System.out.println("Testing the removeNode function");
		nodeA.removeNodeAfterThis();
		
		System.out.println("Testing the toString function");
		System.out.println(nodeA.toString());
		
		System.out.println("Testing the listLength function");
		System.out.println(IntNode.listLength(nodeA));
		
		System.out.println("Testing the search function");
		System.out.println(IntNode.search(nodeA,100));
		System.out.println(IntNode.search(nodeA,3));
		System.out.println(IntNode.search(nodeA,5));
		System.out.println(IntNode.search(nodeA, 9));
		
		System.out.println("Testing listSort");
		IntNode nodeC = IntNode.listSort(nodeA);
		System.out.println(nodeC.toString());
		IntNode nodeB = new IntNode(3,null);
		System.out.println(IntNode.listSort(nodeB));
		
		System.out.println("Testing the subtract function.");
		nodeB = new IntNode(100,nodeB);
		nodeB = new IntNode(100, nodeB);
		nodeB = new IntNode(8000, nodeB);
		nodeB = new IntNode(9,nodeB);
		IntNode nodeD = new IntNode();
		System.out.println(nodeC.toString());
		System.out.println(nodeB.toString());
		nodeD = IntNode.subtract(nodeC,nodeB);
		System.out.println(nodeD.toString());
	}
}
