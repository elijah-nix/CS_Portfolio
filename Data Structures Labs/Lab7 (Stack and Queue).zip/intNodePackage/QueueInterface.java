package intNodePackage;

public interface QueueInterface<G> {
	public void enqueue(G element);
	G dequeue();
	G front();
	int size();
	boolean isEmpty();
}
