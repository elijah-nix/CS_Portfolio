package intNodePackage;

public class StackTest {
	
	public static void main(String args[]) {
		
	LinkStack<Integer> intStack = new LinkStack<Integer>();
	LinkStack<String> stringStack = new LinkStack<String>();
	
	System.out.println(intStack.isEmpty());
	intStack.push(17);
	intStack.push(6);
	intStack.push(13);
	System.out.println(intStack.getNode().toString());
	System.out.println(intStack.pop());
	System.out.println(intStack.getNode().toString());
	System.out.println(intStack.top());
	System.out.println(intStack.getNode().toString());
	System.out.println(intStack.size());
	System.out.println(intStack.isEmpty());
	
	System.out.println("");
	
	//The two following lines test NullPointerExceptions 
	//System.out.println(stringStack.size());
	//System.out.print(stringStack.top());
	stringStack.push("Elephants");
	stringStack.push("Leaves");
	stringStack.push("Toaster");
	System.out.println(stringStack.getNode().toString());
	System.out.println(stringStack.pop());
	System.out.println(stringStack.getNode().toString());
	System.out.println(stringStack.top());
	System.out.println(stringStack.getNode().toString());
	System.out.println(stringStack.size());
	System.out.println(stringStack.isEmpty());
	
	}
	
}
