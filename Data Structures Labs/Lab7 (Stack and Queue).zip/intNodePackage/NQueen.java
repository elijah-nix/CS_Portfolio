package intNodePackage;

	

public class NQueen {
	public static String nQueen(int n) {
		boolean conflict = false;
		int Qpos = 0;
		LinkStack<Integer> safeQueens = new LinkStack<Integer>();
		safeQueens.push(0);
		while (safeQueens.size() < n) {
			System.out.println("safeQueens.size() < " + n);
			while (Qpos < n) {
				System.out.println("safeQueens.size() BEFORE checkConflict: " + safeQueens.size());
				conflict = checkConflict(Qpos, safeQueens);
				System.out.println("safeQueens.size() AFTER checkConflict: " + safeQueens.size());
				if(!conflict) {
					System.out.println("No conflict!");
					safeQueens.push(Qpos);
				} else {
					System.out.println("Conflict!");
					Qpos++;
				}
			}
			while (!safeQueens.isEmpty() && Qpos > n) {
				Qpos  = safeQueens.pop();
			}
			if(Qpos > n) {
				return "No solution";
			}
			Qpos = 0;
		}
		return printStack(safeQueens);
	}
	
	public static boolean checkConflict(int _Qpos, LinkStack<Integer> _safeQueens) {
		if(_safeQueens.size() == 1) {
			return false;
		}
		int upDiag = _Qpos;
		int downDiag = _Qpos;
		int left = _Qpos;
		int tempPop;
		int originalAmount = _safeQueens.size();
		int[] popHolder = new int[_safeQueens.size()];
		for(int i = 0; i < originalAmount; i++) {
			tempPop = _safeQueens.pop();
			System.out.println("tempPop: " + tempPop);
			upDiag++;
			downDiag--;
			if(tempPop == upDiag || tempPop == downDiag || tempPop == left) {
				popHolder[i] = tempPop;
				for(int j = i; j >= 0; j--) {
					_safeQueens.push(popHolder[j]);
				}
				return true;
			} else {
				popHolder[i] = tempPop;
			}
		}
		for(int j = originalAmount-1; j >= 0; j--) {
			_safeQueens.push(popHolder[j]);
		}
		return false;
	}
	
	public static String printStack(LinkStack<Integer> _safeQueens) {
		int temp;
		int size = _safeQueens.size();
		String output = "";
		for(int i = 0; i < _safeQueens.size(); i++) {
			temp = _safeQueens.pop();
			for(int j = 0; j < size; j++) {
				if(j != temp) {
					output += "-"; 
				} else {
					output += temp;
				}	
			}
			output += "\n";
		}
		return output;
	}
	
	public static void main(String args[]) {
		System.out.println(nQueen(4));
	}
	
	
}
		
		
		
		
		
		
//		int y = 0;
//		int yUp = 0;
//		int x = 0;
//		int yLeft;
//		int yRight;
//		Integer[][] chessboard = new Integer[n][n];
//		boolean success = false;
//		boolean conflict = false;
//		chessboard[0][0] = 1;
//		safeQueens.push(chessboard);
//		while(!success && !safeQueens.isEmpty()) {
//			yLeft = x - 1;
//			yRight = x + 1;
//			yUp = y - 1;
//			y++;
//			for(int i = 0; i < y; i++) {
//				if((y-1 >= 0 && chessboard[x][y-1] == 1)
//						|| (yLeft >= 0 && chessboard[yLeft][y - 1] == 1)
//						|| (yRight < 5 && chessboard[yRight][y + 1] == 1)) {
//					conflict = true;	
//				}
//				if(conflict == true) {
//					if(x == 4) {
//						chessboard = safeQueens.pop();
//					} else {
//						x++;
//					}
//				}
//				yLeft--;
//				yRight++;
//			}
//			if(conflict == false && safeQueens.size() == n) {
//				success = true;
//			}
//		}
//		
//	}
//}
