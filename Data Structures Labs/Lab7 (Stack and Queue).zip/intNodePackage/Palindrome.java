package intNodePackage;

public class Palindrome {
	public static boolean isPalindrome(String input) {
		LinkStack<String> stringStack = new LinkStack<String>();
		LinkedQueue<String> stringQueue = new LinkedQueue<String>();
		String[] splited = input.split(" ");
		for(int i = 0; i < splited.length; i++) {
			splited[i] = splited[i].replaceAll("[^a-zA-Z']", "");
			splited[i] = splited[i].toLowerCase();
			stringStack.push(splited[i]);
			stringQueue.enqueue(splited[i]);
		}
		for(int i = 0; i < stringQueue.size(); i++) {		
			if(!(stringStack.pop().equals(stringQueue.dequeue()))) {
				return false;
			}
		}
		return true;
	}
	
	public static void main(String args[]) {
		System.out.println(isPalindrome("You can cage a swallow, can't you, but, you can't swallow a cage, can you?"));
		System.out.println(isPalindrome("one two three four two one"));
		System.out.println(isPalindrome("one two three three two one"));
		System.out.println(isPalindrome("ONE TWO THREE TWO one."));
		System.out.println(isPalindrome("ONE TWO THREE TW'O one."));

	}
}
