package intNodePackage;

public class SNode<Q>{

	private Q data;
	private SNode<Q> link;
	
	//Constructors
	/**
	 * 
	 */
	public SNode() {
		data = null;
		link = null;
	}
	
//	public SNode(Q _data, SNode<Q> _node) {
//		data = _data;
//		link = _node;
//	}

	//Getters and setters
	public Q getData() {
		return data;
	}

	public void setData(Q data) {
		this.data = data;
	}

	public SNode<Q> getLink() {
		return link;
	}

	public void setLink(SNode<Q> node) {
		this.link = node;
	}
	
	/**
	 * @returns String version of the Linked List
	 */
	public String toString() {
		String nodeString = "";
		SNode<Q> tempNode = this;
		while(tempNode.link != null) {
			nodeString += (tempNode.getData() + "->");
			tempNode = tempNode.getLink();
		}
		nodeString += (tempNode.getData());
		return nodeString;
	}
	
	/**
	 * @param head (head of a linked list
	 * @return numNodes (number of nodes in the linked list
	 */
	public int listLength() {
		int numNodes = 1;
		SNode<Q> tempNode = this;
		while(tempNode.link != null) {
			tempNode = tempNode.link;
			++numNodes;
		}
		return numNodes;
	}
	/**
	 * @param newData (Data to be added to the next node
	 * 
	 */
//	public void addNodeAfterThis(int newData) {
//		IntNode newNode = new IntNode();
//		newNode.setData(newData);
//		newNode.setNode(this.node);
//		this.node = newNode;
//	}
//	
//	/**
//	 * @precondition node != null
//	 */
//	public void removeNodeAfterThis() {
//		if(this.node != null) {
//		this.node = this.node.node;
//		}
//	}
	
	/**
	 * @param head (first node in the linked list)
	 * @param data (data value to be searched for)
	 * @return boolean (true if the value is found in the linked list)
	 */
//	public static boolean search(IntNode head, int data) {
//		IntNode temp = head;
//		while(temp.node != null) {
//			if(temp.data == data) {
//				return true;
//			} else {
//				temp = temp.node;
//			}
//		}
//		if(temp.data == data) {
//			return true;
//		}
//		return false;
//	}
	
	/**
	 * @param head (head of the linked list)
	 * @return IntNode newHead (sorted version of the parameter in ascending order)
	 */
//	public static IntNode listSort(IntNode head) {
//		IntNode cursor;
//		IntNode prevCursor = null;
//		IntNode max;
//		IntNode prevMax = null;
//		IntNode tempHead;
//		int nodeCounter = listLength(head);
//		IntNode newHead = new IntNode();
//		for(int i = nodeCounter; i > 0; i--) {
//			 int altCounter = listLength(head);
//			 //Use tempHead so we don't mess up head
//			 tempHead = head;
//			 //first node is max
//			 max = tempHead;
//			 //first node is cursor
//			 cursor = tempHead;
//			 for(int j = altCounter; j > 0; j--){
//				 //If max is found, max = cursor and prevmax = prevcursor
//				 if(cursor.data > max.data){
//					 max = cursor;
//					 //System.out.println("New max is " + cursor.data);
//					 prevMax = prevCursor;
//				 }
//				 prevCursor = cursor;
//				 cursor = cursor.node;
//			 }
//			//Sets newHead depending on where the node is in the tempHead
//			if(i == nodeCounter) {
//				newHead.data = max.data;
//			} else if(i == 1){
//				newHead = new IntNode(tempHead.data, newHead);
//				return newHead;
//			} else {
//				newHead = new IntNode(max.data, newHead);
//			}
//			
//			if (max == tempHead){
//				head = head.node;
//			} else {
//				prevMax.removeNodeAfterThis();
//			}
//			 //System.out.println(newHead.toString());
//		}
//		return newHead;
//	}
	
	/**
	 * @param list1 (linked list to be shaved down)
	 * @param list2 (linked list to find duplicates)
	 * @return new list1 but without the duplicates found between list1 and list2
	 */
//	public static IntNode subtract(IntNode list1, IntNode list2) {
//		//System.out.println("list1 = " + list1.toString() + "\nlist2 = " + list2.toString());
//		IntNode newList = new IntNode();
//		IntNode cursor1 = null;
//		IntNode cursor2 = null;
//		IntNode prevCursor1 = null;
//		IntNode prevCursor2 = null;
//		IntNode tempHead1 = null;
//		IntNode tempHead2 = null;
//		int node1Counter = listLength(list1);
//		int node2Counter = listLength(list2);
//		int potentialNewData;
//		tempHead1 = list1;
//		cursor1 = tempHead1;
//		potentialNewData = tempHead1.data;
//		boolean firstNewNode = true;
//		//Outside loop for list1
//		for(int i = node1Counter; i > 0; i--) {
//			tempHead2 = list2;
//			cursor2 = tempHead2;
//			//Inside loop for loop2
//			for(int j = node2Counter; j > 0; j--) {
//				//System.out.println(cursor1.data);
//				//System.out.println(cursor2.data);
//				//if the two data are equal, remove them from both lists
//				if(cursor1.data == cursor2.data) {
//					//System.out.println("MATCH: removing after " + prevCursor1.data + " in list1 and after " + prevCursor2.data + " in list2");
//					j = 0;
//					--node1Counter;
//					--node2Counter;
//					//If either datum is at the head
//					if (cursor1 == tempHead1){
//						list1 = list1.node;
//					} else {
//						prevCursor1.removeNodeAfterThis();
//					}
//					
//					if (cursor2 == tempHead2){
//						list2 = list2.node;
//					} else {
//						prevCursor2.removeNodeAfterThis();
//					}
//				//If not, the cursor moves to the next node
//				} else {
//					//System.out.println("Not Equal");
//					prevCursor2 = cursor2;
//					if(cursor2.node == null) {
//						//if list 1 datum does not equal any of the list 
//						if(firstNewNode == true) {
//							newList.setData(potentialNewData);
//							firstNewNode = false;
//						} else {
//							newList = new IntNode(potentialNewData, newList);
//						}
//					} else {
//						cursor2 = cursor2.node;
//					}
//				}
//			}
//			prevCursor1 = cursor1;
//			if(cursor1.node != null) {
//				cursor1 = cursor1.node;
//				potentialNewData = cursor1.data;
//				//System.out.println("Potential new data: " + potentialNewData);
//			}
//		}
//	return newList;
//	}
}
