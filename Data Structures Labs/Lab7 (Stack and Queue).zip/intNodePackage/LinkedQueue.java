package intNodePackage;

public class LinkedQueue<G> implements QueueInterface<G>{
	
	private SNode<G> front;
	private SNode<G> rear;
	private int numElements;
	
	public LinkedQueue(){
		front = new SNode<G>();
		rear = new SNode<G>();
		numElements = 0;
		
	}
	
	public SNode<G> getFront() {
		return front;
	}

	public void setFront(SNode<G> front) {
		this.front = front;
	}

	public SNode<G> getRear() {
		return rear;
	}

	public void setRear(SNode<G> rear) {
		this.rear = rear;
	}

	public int getNumElements() {
		return numElements;
	}

	public void setNumElements(int numElements) {
		this.numElements = numElements;
	}

	public void enqueue(G element) {
		if(numElements == 0) {
			front.setData(element);
			rear.setData(element);
		} else if(numElements == 1) {
			rear.setData(element);
			front.setLink(rear);
		} else {
			SNode<G> temp = new SNode<G>();
			temp.setData(element);
			rear.setLink(temp);
			rear = temp;
		}
		numElements++;
	}
	
	public G dequeue() {
		if(numElements > 0) {
			G temp = front.getData();
			front = front.getLink();
			numElements--;
			return temp;
		} else {
			return null;
		}
	}
	
	public G front() {
		if(numElements > 0) {
			return front.getData();
		} else {
			return null;
		}
	}
	
	public int size() {
		return numElements;
	}
	
	public boolean isEmpty() {
		if(numElements == 0) {
			return true;
		} else {
			return false;
		}
	}
}
