package intNodePackage;

public class LinkStack<Q> implements StackInterface<Q>{
	
	private SNode<Q> node;
	
	public SNode<Q> getNode() {
		return node;
	}

	public void setNode(SNode<Q> node) {
		this.node = node;
	}
	
	//public LinkStack()
	
	public void push(Q data) {
		SNode<Q> temp = new SNode<Q>();
		temp.setData(data);
		temp.setLink(node);
		node = temp;
	}

	public Q pop() {
		Q temp = node.getData();
		node = node.getLink();
		return temp;
	}
	
	public Q top() {
		if (node == null) {
			throw new NullPointerException("Stack is Empty");
		}
		return node.getData();
	}
	
	public int size() {
		if(node == null) {
			return 0;
		}
		return node.listLength();
	}
	
	public boolean isEmpty() {
		if (node == null) {
			return true;
		} else {
			return false;
		}
	}
}
