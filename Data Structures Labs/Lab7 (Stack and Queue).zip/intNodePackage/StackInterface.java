package intNodePackage;

public interface StackInterface<Q> {
	public void push(Q element);
	public Q pop();//Exceptions?
	public Q top();
	public int size();
	public boolean isEmpty();
}
