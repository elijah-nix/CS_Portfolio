package intNodePackage;


public class Postfix {
	
	//helper function to determine if a string is an int
	//https://tinyurl.com/dhhyja5e
	static boolean isInt(String s)
	{
	 try
	  { @SuppressWarnings("unused")
	int i = Integer.parseInt(s); return true; }

	 catch(NumberFormatException er)
	  { return false; }
	}
	
	public static int evaluate(String postfix) {
		int tempInt;
		int pop1;
		int pop2;
		LinkStack<Integer> intStack = new LinkStack<Integer>();
		String rawString = postfix;
		String[] splitString = rawString.split(" ");
		for(int i = 0; i < splitString.length; i++) {
			if(isInt(splitString[i])) {
				tempInt = Integer.parseInt(splitString[i]);
				intStack.push(tempInt);
			} else {
				switch(splitString[i]) {
					case "/":
						pop1 = intStack.pop();
						pop2 = intStack.pop();
						intStack.push(pop2/pop1);
						break;
					case "*":
						pop1 = intStack.pop();
						pop2 = intStack.pop();
						intStack.push(pop2*pop1);
						break;
					case "+":
						pop1 = intStack.pop();
						pop2 = intStack.pop();
						intStack.push(pop2 + pop1);
						break;
					case "-":
						pop1 = intStack.pop();
						pop2 = intStack.pop();
						intStack.push(pop2 - pop1);
				}
			}
		}
		return intStack.pop();
	}
	
	public static void main(String args[]) {
		
		System.out.println(evaluate("1 2 5 + 2 / -1 - *"));
		System.out.println(evaluate("10 2 5 + 2 / -1 - *"));
		System.out.println(evaluate("10 2 5 + 2 * -1 - -"));
		
	}
}
