package intNodePackage;


public class ArrayQueue<G> implements QueueInterface<G> {
	
	private G[] array;
	private int numItems;
	private int frontLoc;
	private int rearLoc;
	
	@SuppressWarnings("unchecked")
	public ArrayQueue() {
		final int INITIAL_CAPACITY = 3;
		array = (G[]) new Object[INITIAL_CAPACITY];
		numItems = 0;
		frontLoc = 0;
		rearLoc = 0;
	}
	
	public void enqueue(G data) {
		ensureCapacity(array, rearLoc);
		array[frontLoc + rearLoc] = data;
//		if(numItems == 0) {
//			array[0] = element;
//		} else if(numItems == 1) {
//			element);
//			front.setLink(rear);
//		} else {
//			SNode<G> temp = new SNode<G>();
//			temp.setData(element);
//			rear.setLink(temp);
//			rear = temp;
//		}
		numItems++;
		rearLoc++;
	}
	
	public G dequeue() {
		if(numItems > 1) {
			G temp = array[frontLoc];
			frontLoc++;
			numItems--;
			return temp;
		} else {
			return null;
		}
	}
	
	public G front() {
		if(numItems > 0) {
			return array[frontLoc];
		} else {
			return null;
		}
	}
	
	public int size() {
		return numItems;
	}
	
	public boolean isEmpty() {
		if(numItems > 0) {
			return false;
		} else {
			return true;
		}
	}
	
	@SuppressWarnings("unchecked")
	public void ensureCapacity(G[] array, int minimumCapacity) {
		if (array.length - 2 < minimumCapacity){
			G[] biggerArray;
			biggerArray = (G[]) new Object[(minimumCapacity + 1)* 2];
			System.arraycopy(array, frontLoc, biggerArray, 0, numItems);
			rearLoc-=frontLoc;
			frontLoc = 0;
			array = biggerArray;
		}
	}
	
}
