package doublyLinkedList;

public class DoublyLinkedListDummy {
	private DIntNode head;
	private DIntNode tail;
	
	//Getters and Setters
	public DIntNode getHead() {
		return head;
	}
	
	public void setHead(DIntNode head) {
		this.head = head;
	}

	public DIntNode getTail() {
		return tail;
	}

	public void setTail(DIntNode tail) {
		this.tail = tail;
	}

	//Constructor
	public DoublyLinkedListDummy() {
		head = new DIntNode();
		tail = new DIntNode();
		head.setNext(tail);
		tail.setPrev(head);
	}
	
	//Add a DIntNode with data of parameter int "element" to the end of the list
	//Time complexity: O(n)
	public void addEnd(int element) {
		DIntNode newNode = new DIntNode(element);
		DIntNode temp = head;
		while(temp.getNext() != tail) {
			temp = temp.getNext();
		}
		temp.setNext(newNode);
		newNode.setNext(tail);
		newNode.setPrev(temp);
		this.tail.setPrev(newNode);
	}
	
	//Removes the first DIntNode from the dummy node
	//Time complexity: O(1)
	public void removeFromHead() {
		if(head.getNext() != tail) {
			head.getNext().getNext().setPrev(head);
			head.setNext(head.getNext().getNext());
		}
	}
	
	//Returns a string version of the dummy node
	public String toString() {
		String output = "(Forward) ";
		DIntNode temp = head;
		while(temp.getNext() != tail) {
			output += temp.getNext().getData() + "<->";
			temp = temp.getNext();
		}
		if(head.getNext() != tail) {
			output = output.substring(0, output.length() - 3);
		}
		output += "\n(Backward) ";
		DIntNode temp2 = tail;
		while(temp2.getPrev() != head) {
			output += temp2.getPrev().getData() + "<->";
			temp2 = temp2.getPrev();
		}
		if(head.getNext() != tail) {
			output = output.substring(0, output.length() - 3);
		}
		return output;
	}
	
	//Counts the number of DIntNodes with data value parameter int "e"
	//Time Complexity: O(n)
	public int countOccurrance(int e) {
		DIntNode temp = head;
		int count = 0;
		while(temp.getNext() != tail) {
			if (temp.getNext().getData() == e) {
				count += 1;
			}
			temp = temp.getNext();
		}
		return count;
	}
	
	//Removes all DIntNodes with data of value parameter "e"
	//Time Complexity: O(n)
	public boolean removeAll(int e) {
		boolean eFound = false;
		DIntNode temp = head;
		while(temp != tail) {
			if(temp.getData() == e) {
				temp.getNext().setPrev(temp.getPrev());
				temp.getPrev().setNext(temp.getNext());
				eFound = true;
			}
			temp = temp.getNext();
		}
		return eFound;
	}
	
	//Removes all DIntNode that are data duplicates
	//Returns a dummy list with no duplicates
	//Time complexity: O(n^2)
	public DoublyLinkedListDummy removeDuplicates() {
		DIntNode temp = head;
		DIntNode temp2 = temp.getNext();
		while(temp != tail) {
			while(temp2 != tail){
				if(temp2.getData() == temp.getData() && temp != head) {
					temp2.getNext().setPrev(temp2.getPrev());
					temp2.getPrev().setNext(temp2.getNext());
				}
				temp2 = temp2.getNext();
			}
			temp = temp.getNext();
			temp2 = temp.getNext();
		}
		return this;
	}
	
	
	//Prints out data pairs from parameter DoublyLinkedListDummy "dummyList" that equal
	//the given int parameter "y"
	//Time complexity: O(n)
	public static void pairs(DoublyLinkedListDummy dummyList, int y) {
		int sum = y;
		String output = "";
		DoublyLinkedListDummy list = dummyList;
		DIntNode listTail = list.tail.getPrev();
		DIntNode listHead = list.head.getNext();
		while(listTail != listHead || listTail.getData() < listHead.getData()) {
			if(listTail.getData() + listHead.getData() == sum) {
				//System.out.println("just right " + listHead.getData() + " " + listTail.getData());
				output += "(" + listHead.getData() + "," + listTail.getData() + "),";
				listTail = listTail.getPrev();
				listHead = listHead.getNext();
			} else if(listTail.getData() + listHead.getData() > sum){
				//System.out.println("too high " + listHead.getData() + " " + listTail.getData());
				listTail = listTail.getPrev();
			} else if(listTail.getData() + listHead.getData() < sum) {
				//System.out.println("too low " + listHead.getData() + " " + listTail.getData());
				listHead = listHead.getNext();
			}
		}
		output = output.substring(0,output.length()-1);
		System.out.println(output);
	}
	
	public static void main(String args[]) {
		//Testing the constructor
		DoublyLinkedListDummy test = new DoublyLinkedListDummy();
		
		//Testing removeFromHead method with only a dummy
		test.removeFromHead();
		System.out.println(test.toString());
		
		//Testing the addEnd method and toString method
		test.addEnd(56);
		System.out.println(test.toString());
		test.addEnd(12);
		test.addEnd(120);
		test.addEnd(67);
		System.out.println(test.toString());
		
		//Testing the removeFromHead method with many DIntNodes
		test.removeFromHead();
		System.out.println(test.toString());
		test.removeFromHead();
		System.out.println(test.toString());
		
		//Testing the countOccurrence method
		System.out.println(test.countOccurrance(0));
		System.out.println(test.countOccurrance(67));
		test.addEnd(67);
		System.out.println(test.countOccurrance(67));

		//Testing the removeAll method
		test.addEnd(67);
		test.addEnd(67);
		test.addEnd(780);
		test.addEnd(67);
		System.out.println(test.toString());
		System.out.println(test.removeAll(67));
		System.out.println(test.toString());
		
		//Testing the removeDuplicates method
		test.addEnd(0);
		test.addEnd(67);
		test.addEnd(0);
		test.addEnd(70);
		test.addEnd(0);
		test.addEnd(67);
		test.addEnd(70);
		System.out.println(test);
		System.out.println(test.removeDuplicates());
		
		//Testing the pairs method
		DoublyLinkedListDummy test2 = new DoublyLinkedListDummy();
		test2.addEnd(1);
		test2.addEnd(3);
		test2.addEnd(4);
		test2.addEnd(7);
		test2.addEnd(8);
		test2.addEnd(9);
		test2.addEnd(10);
		System.out.println(test2);
		pairs(test2, 12);
		test2.addEnd(11);
		pairs(test2, 12);
		
		
		
	}
}
