package recursive;

public class RecrsiveQuestion {
	//Converts a string (input) containing only digits into an integer
	public static int convert(String input) {
		if (input.length() >= 1) {
			//System.out.println(input + " length is >= 1");
			return (input.charAt(input.length()-1) - '0') + 10 * convert(input.substring(0,input.length()-1));
		}
		return 0;
	}
	
	//Computes a variation of the Ackermann's function with two integers (x, y)
	//if either or both inputs are negative, the method will return -1
	public static int Ackermann(int x, int y) {
		if(x >= 1 && y >= 2) {
			System.out.println("x = " + x + " y = " + y);
			return Ackermann(x-1,Ackermann(x,y-1));
		} else if (x == 0) {
			System.out.println("x = " + x + " y = " + y);
			return 2 * y;
		} else if (x >= 1 && y == 1) {
			System.out.println("x = " + x + " y = " + y);
			return 0;
		} else if (x >= 1 && y == 0) {
			System.out.println("x = " + x + " y = " + y);
			return 2;
		} else{
			System.out.println("x = " + x + " y = " + y);
			return -1;
		}
	}
	
//	public static int[] newArray(int[] oldArray, int j) {
//		int[] newArray = new int[oldArray.length - 1];
//		for(int i = 0; i < oldArray.length; i++) {
//			if(i > j) {
//				newArray[i-1] = oldArray[i];
//			} else if(i < j) {
//				newArray[i] = oldArray[i];
//			}
//		}
//		return newArray;
//	}
	
//	public static void permutations(int[] num) {
//		if(num.length == 1) {
//			System.out.println(num[0]);
//		} else {
//			for(int i = 0; i < num.length; i++) {
//				System.out.print(num[i]);
//				permutations(newArray(num,i));
//			}
//		}
//		//System.out.println("");
//	}
	
	//Prints all permutations of and int[] (array)
	//When calling, prefixLen should be 0
	public static void permuteArray(int[] array, int prefixLen) {
		//System.out.println("PrefixLen = " + prefixLen);
		if(prefixLen == array.length) {
			for(int i = 0; i < array.length; i++) {
				System.out.print(array[i]);
			}
			System.out.println("");
			return;
		}
		if(prefixLen < array.length) {
			for(int i = prefixLen; i < array.length; i++) {
				int temp = array[prefixLen];
				array[prefixLen] = array[i];
				array[i] = temp;
				permuteArray(array, prefixLen + 1);
				temp = array[prefixLen];
				array[prefixLen] = array[i];
				array[i] = temp;
			}
		}
	}
	
	//Instructs how to solve Hanoi's Towers with different numbers of disks (numDisks)
	//When calling the function, the three String parameters should be "left", "right", and "middle" respectively
	public static void hanoi(String left, String right, String middle, int numDisks) {
		if(numDisks == 0) {
			return;
		}
		hanoi(left, middle, right, numDisks - 1);
		System.out.println("Move " + numDisks + " from " + left + " to " + right + ".");
		hanoi(middle, right, left, numDisks - 1);
	}
	
	//Outputs the Sum of the reciprocals from 1 to sum
	//If sum is 0 or negative, the method returns 0
	public static double sumover(int sum) {
		if(sum > 1) {
			//System.out.println("sum = " + sum);
			return (1.0/sum + sumover(sum - 1));
		} else if(sum == 1){
			return 1.0;
		} else {
			return 0.0;
		}
	}
	
	//Calculates and returns the double value of x to the power of n
	//O(log(n))
	public static double pow(double x, int n){
		System.out.println("Calling function");
		if (x == 0 && n <= 0)
			throw new IllegalArgumentException("x is zero and n=" + n);
		else if (x == 0)
			return 0;
		else if (n == 0)
			return 1;
		else if (n > 0 && n % 2 == 0) {
			double temp = pow(x, n/2);
			return temp * temp;
		}else if (n > 0) {
			return x * pow(x, n-1);
		}
		else // x is nonzero, and n is negative.
			return 1/pow(x, -n);
	}
	
	public static void main(String args[]) {
		System.out.println("Converting String digits to integers");
		System.out.println(convert("123456"));
		System.out.println(convert("1324564294"));
		System.out.println(convert("1"));
		System.out.println(convert(""));
		System.out.println("");

		
		System.out.println("Using Ackermann");
		System.out.println(Ackermann(2,2));
		System.out.println(Ackermann(3,3));
		System.out.println(Ackermann(2,7));
		System.out.println("");
		
		int[] data1 = new int[] {1};
		int[] data2 = new int[] {1,2};
		int[] data5 = new int[] {1,2,3,4,5};
		//int[] data10 = new int[] {1,2,3,4,5,6,7,8,9,10};
		
		System.out.println("Permuting Arrays");
		permuteArray(data1,0);
		System.out.println("");
		permuteArray(data2,0);
		System.out.println("");
		permuteArray(data5,0);
		//System.out.println("");
		//permuteArray(data10,0);
		System.out.println("");
		
		System.out.println("sumover method");
		System.out.println(sumover(5));
		System.out.println(sumover(3));
		System.out.println(sumover(1));
		System.out.println(sumover(0));
		System.out.println("");
		
		System.out.println("Calculating power");
		System.out.println(pow(2, 256));
		System.out.println(pow(2, -256));
		System.out.println("");
		
		System.out.println("Solving Hanoi");
		hanoi("left", "right", "middle", 3);
		System.out.println("");
		hanoi("left", "right", "middle", 4);
		System.out.println("");
		hanoi("left", "right", "middle", 5);
		System.out.println("");
	}
}
